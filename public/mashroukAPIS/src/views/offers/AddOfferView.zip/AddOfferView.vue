<!-- eslint-disable vuejs-accessibility/click-events-have-key-events -->
<!-- eslint-disable vuejs-accessibility/label-has-for -->
<!-- eslint-disable vuejs-accessibility/anchor-has-content -->
<!-- eslint-disable max-len -->
<template>
  <section class="back-head  m-t-20">
    <div class="container">
      <div>
        <div @click="goBack" style="cursor: pointer;"><img class="icone-resize" src="../../assets/imgs/right-arrow.png" alt=""></div>
      </div>
      <div class="m-r-20">
        <h3>اضافة عرض شراكة </h3>
      </div>
    </div>
  </section>

  <h1 style="text-align: center;">
    نموذج عرض شراكة
  </h1>
  <section class="rod">
    <div class="container">
      <h2> هل مواصفات وموقع العقار مناسب ام لا</h2>
      <form class="roleForm">
        <label class="radio-lab">
          <input type="radio" name="aqar-type" value="1" class="radio-circle" v-model="iSpecificationsOK">
          نعم
        </label>
        <label class="radio-lab">
          <input type="radio" name="aqar-type" value="0" class="radio-circle" v-model="iSpecificationsOK" >
          لا
        </label>
      </form>

      <!-- Radio buttons for yes and no -->
      <h2>هل مبلغ الشراكة مناسب أم لا</h2>
      <form class="roleForm">
        <label class="radio-lab">
          <input type="radio" name="aqar-type" value="1" class="radio-circle" v-model="isAmountofMoneyOK">
          نعم
        </label>
        <label class="radio-lab">
          <input type="radio" name="aqar-type" value="0" class="radio-circle" v-model="isAmountofMoneyOK">
          لا
        </label>
      </form>
    </div>
  </section>

  <section v-if="isAmountofMoneyOK === '0' ">
    <div class="container">
      <div class="cell">
        <label for="myRange2" class="Renge-style">
          اختر المبلغ الذي تستطيع دفعه: <p style="margin-right: 5px;">{{ suggestedAmount }}</p>
          <p style="font-weight: bold;">&nbsp;&nbsp;صافي (يشمل الضريبة)</p>
        </label>
        <input type="range" min="100000" max="5000000" step="50000" class="styled-range" v-model="suggestedAmount">
      </div>
      <div class="Reng-flex">
        <div>100,000&nbsp;ريال</div>
        <div class="paddI"></div>
        <div class="paddI"></div>
        <div class="paddI"></div>
        <div class="padd"></div>
        <div class="padd">5,000,000&nbsp;ريال</div>
      </div>

    </div>
  </section>

  <section>
    <div class="container">
      <div style="display: flex; justify-content: space-between; padding:30px 0;">
        <button class="small-btn" @click="submitOffer">قدم عرض شراكة</button>
        <a @click="goBack" class="small-btn" style="background-color:transparent; color:var(--main-color); border:none; font-weight:bold;">رجوع</a>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'AddOffer',
  data() {
    return {
      suggestedAmount: 100000,
      iSpecificationsOK: '',
      isAmountofMoneyOK: '',
      commercial: '',
      real_estate_yes: '',
      real_estate_no: '',
      token: '',
      Iduser: '',
      realEstateId: '',
    };
  },
  mounted() {
    this.realEstateId = this.$route.params.id;
    console.log('Real Estate ID:', this.realEstateId);
    this.Iduser = localStorage.getItem('userId');
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    async submitOffer() {
      // const corsProxyUrl = 'https://your-cors-proxy-instance.herokuapp.com/'; // Replace with your own CORS proxy instance
      const apiUrl = 'https://www.mashrook.somee.com/Home/AddRequest_Real_Estate_Yes';
      const payload = {
        requester: this.Iduser,
        commercial: '',
        real_estate_yes: '',
        real_estate_no: '',
      };

      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'text/plain',
          },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          throw new Error(`Failed to save form. Status: ${response.status}`);
        }

        this.$router.push('/FormSuccess');
      } catch (error) {
        console.error('Error saving form:', error.message);
      }
    },

  },
};
</script>
