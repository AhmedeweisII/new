/* eslint-disable linebreak-style */
// eslint-disable-next-line import/prefer-default-export
export const BASE_URL = 'https://www.mashrook.somee.com';
export const DEV_BASE_URL = 'http://localhost:3000';
