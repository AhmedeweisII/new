<!-- eslint-disable max-len -->
<!-- eslint-disable vuejs-accessibility/anchor-has-content -->
<template>
  <section class="back-head  m-t-20">
    <div class="container">
        <router-link to="/main"><img class="icone-resize" src="../../assets/imgs/right-arrow.png" alt=""></router-link>
            <div class="m-r-20">
        <h3>اضافة طلب شريك </h3>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'FormBack',
};
</script>
