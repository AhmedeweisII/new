<!-- eslint-disable vuejs-accessibility/click-events-have-key-events -->
<!-- eslint-disable vuejs-accessibility/anchor-has-content -->
<!-- eslint-disable max-len -->
<template>
<div></div>
</template>

<script>
// import axios from 'axios';

export default {
  name: 'ChatHeader',
  data() {
    return {

      conversation_id: null,
      Iduser: '',
    };
  },
  methods: {

  },
};
</script>
