<!-- eslint-disable vuejs-accessibility/alt-text -->
<!-- eslint-disable max-len -->
<!-- eslint-disable vuejs-accessibility/anchor-has-content -->
<template>
<div></div>
</template>

<script>

export default {
  name: 'MessageInput',
};
</script>
