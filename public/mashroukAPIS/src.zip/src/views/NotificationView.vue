<!-- eslint-disable vuejs-accessibility/heading-has-content -->
<!-- eslint-disable vuejs-accessibility/anchor-has-content -->
<!-- eslint-disable vuejs-accessibility/alt-text -->
<!-- eslint-disable max-len -->
<template>
  <LogInHeader />
  <section>
    <h1 class="container" style="font-size:1.8em;">الاشعارات</h1>
  </section>
  <section class="Speach">
    <div class="container">
      <div class="Frame5">
        <div class="Card">
          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">9:00 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/GroupsFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> اكتمل عدد الشركاء في طلب تملك فيلا وحدات مفرزة (رقم الطلب 2022)
                  </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">7:59 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/FileCopyFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> لقد انتهت فترة طلب العقار قم بالتجديد .. طلب تملك فيلا وحدات مفرزة (رقم الطلب
                    2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Label">
                  <div class="">6:21 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/GroupsFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> تم بدء الشراكة للطلب تملك فيلا وحدات مفرزة (رقم الطلب 2022)

                  </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">5:49 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/MessageFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> لديك رسائل جديدة لم تقم بفتحها في مجموعة الشراكة تملك فيلا وحدات مفرزة (رقم
                    الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">2:36 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/robot.png" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> تم الدفع بنجاح يمكن الان الدخول للمحادثة تملك فيلا وحدات مفرزة (رقم الطلب 2022)
                  </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">1:20 PM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/PersonRemoveFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> قام محمد ب ازالتك من طلب تملك فيلا وحدات مفرزة (رقم الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Label">
                  <div class="">11:01 AM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/robot.png" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> سارع بالدفع ودخول المحادثة لطلب تملك فيلا وحدات مفرزة (رقم الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>

          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Label">
                  <div class="">11:00 AM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/PlaylistAddCheckCircleFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head"> تم قبول عرضك من قبل محمد علي طلب تملك فيلا وحدات مفرزة (رقم الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>

          </a>
          <!--  -->

          <!--  -->
          <a href="chat.html" class="Listitem">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Label">
                  <div class="">9:30 AM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/FileCopyFilled.svg" />
                </div>
                <div class="ListitemText">
                  <div class="con-head">ارسل لك أحمد عرض شراكة علي طلبك تملك فيلا وحدات مفرزة (رقم الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>

          </a>
          <!--  -->

          <!--  -->
          <a href="othersFullReq.html" class="Listitem notify-link">
            <div class="container-msg">
              <div class="Newmessage">
                <div class="Badge notify-badge">
                  <div class="Text"></div>
                </div>
                <div class="Label">
                  <div class="">8:53 AM</div>
                </div>
              </div>
              <div class="LeftContent">
                <div class="Avatar remove-circle">
                  <img class="icone-resize" src="../assets/imgs/notiVector.svg">
                </div>
                <div class="ListitemText">
                  <div class="con-head">تم نشر طلب شراكة جديد من قبل محمد تملك فيلا وحدات مفرزة (رقم الطلب 2022) </div>
                  <div class="massage-short">انقر لمعرفة التفاصيل</div>
                </div>
              </div>
            </div>
          </a>
          <!--  -->

        </div>
      </div>
    </div>
    <div>
      <h2>Notifications</h2>
      <ul>
        <li v-for="notification in notifications" :key="notification.id">
          {{ notification.message }}
        </li>
      </ul>
    </div>
  </section>
  <BottomNav />
</template>

<script>
import BottomNav from '@/components/BottomNav.vue';
import LogInHeader from '@/components/LogInHeader.vue';
// import connection from '@/SignalRService';

export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Notification',
  data() {
    return {
      notifications: [],
    };
  },
  mounted() {
    // Assuming "connection" is globally available
    // connection.on('Notify', this.handleNotification);
  },
  methods: {
    // handleNotification(notification) {
    //   console.log(notification);
    //   this.notifications.push(notification);
    // },
  },
  components: {
    BottomNav,
    LogInHeader,
  },
};
</script>
