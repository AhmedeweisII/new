<!-- eslint-disable max-len -->
<template>
  <section  class="FQA">
    <div class="container">
      <div class="FQA-box">
        <img src="../../assets/imgs/question-mark.png" alt="" class="small-img FQA-img">
        <div class="question">
          <h2 class="que-header">ما هي تكلفة الخدمة ؟ </h2>
          <p class="que-parag">انشاء طلب الشراكة مجاني عند الانشاء ولاكن عند الدخول للمحادثة والتواصل مع الشركاء يلزم دفع 10 ريال لكل شريك حتي ينضم للمحادثة</p>
        </div>
      </div>

      <div class="FQA-box">
        <img src="../../assets/imgs/question-mark.png" alt="" class="small-img FQA-img">
        <div class="question">
          <h2 class="que-header"> ما هي خطوات انشاء طلب شراكة</h2>
          <p class="que-parag">  اولا تقوم ب انشاء طلب شراكة ثم يتم الانتظار حتي يقوم المستخدمين بتقديم العروض .. بعد ان تقبل العدد الكافي من الشركاء يدفع كل شريك تكلفة الخدمة وهي 10 ريال ثم يتم دخول المحادثة واكمال الشراكة </p>
        </div>
      </div>

      <div class="FQA-box">
        <img src="../../assets/imgs/question-mark.png" alt="" class="small-img FQA-img">
        <div class="question">
          <h2 class="que-header"> ما هي خطوات انشاء طلب شراكة</h2>
          <p class="que-parag">  اولا تقوم ب انشاء طلب شراكة ثم يتم الانتظار حتي يقوم المستخدمين بتقديم العروض .. بعد ان تقبل العدد الكافي من الشركاء يدفع كل شريك تكلفة الخدمة وهي 10 ريال ثم يتم دخول المحادثة واكمال الشراكة </p>
        </div>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  name: 'FQA',
};
</script>
